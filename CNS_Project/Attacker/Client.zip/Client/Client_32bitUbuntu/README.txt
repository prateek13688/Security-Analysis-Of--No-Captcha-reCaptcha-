Follow the instructions to install the software:
1. Open the Chrome Browser and Press Ctrl+H to open History Window.
2. Select the Extension option given in the side bar.
3. Drag the Client-EXT.crx file in the Client folder to the browser to load the extension.
4. Now open the terminal, navigate to the Client folder.
5. run the "make" command to build and install the software. 